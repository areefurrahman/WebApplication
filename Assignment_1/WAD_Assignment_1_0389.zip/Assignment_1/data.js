// Array of books 
const books = [
  { id: 1, title: "Atomic Habits", author: "James Clear", is_available: true },
  { id: 2, title: "The 7 Habits of Highly Effective People", author: "Stephen Covey", is_available: false },
  { id: 3, title: "Deep Work", author: "Cal Newport", is_available: true },
  { id: 4, title: "The Subtle Art of Not Giving", author: "Mark Manson", is_available: false },
  { id: 5, title: "Can't Hurt Me", author: "David Goggins", is_available: true }
];

module.exports = books;
